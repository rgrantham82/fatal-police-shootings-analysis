import os, zipfile, shutil, math, json, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf
from scipy import stats

warnings.filterwarnings('ignore')

BASE_ZIP = '/mnt/data/police_shootings_cleaned_percapita_package.zip'
OUT_DIR = Path('/mnt/data/police_shootings_next_step_factor_model')
if OUT_DIR.exists():
    shutil.rmtree(OUT_DIR)
(OUT_DIR/'figures').mkdir(parents=True, exist_ok=True)

# -----------------------------
# Load core cleaned data
# -----------------------------
def read_clean_csv(name):
    with zipfile.ZipFile(BASE_ZIP) as z:
        return pd.read_csv(z.open(f'police_shootings_cleaned_percapita/{name}'))

inc = read_clean_csv('clean_incidents_v2.csv')
bridge = read_clean_csv('incident_agency_bridge.csv')
state_year = read_clean_csv('state_year_rates_2015_2024.csv')
state_overall = read_clean_csv('state_overall_rates_2015_2024.csv')

# -----------------------------
# Stable state metadata: land area sq mi. Census Gazetteer-style land area values.
# Used only to create population density/rurality proxy.
# -----------------------------
land_area_sqmi = {
    'AL': 50645, 'AK': 570641, 'AZ': 113594, 'AR': 52035, 'CA': 155779, 'CO': 103642,
    'CT': 4842, 'DE': 1949, 'DC': 61, 'FL': 53625, 'GA': 57513, 'HI': 6423,
    'ID': 82643, 'IL': 55519, 'IN': 35826, 'IA': 55857, 'KS': 81759, 'KY': 39486,
    'LA': 43204, 'ME': 30843, 'MD': 9707, 'MA': 7800, 'MI': 56539, 'MN': 79627,
    'MS': 46923, 'MO': 68742, 'MT': 145546, 'NE': 76824, 'NV': 109781, 'NH': 8953,
    'NJ': 7354, 'NM': 121298, 'NY': 47126, 'NC': 48618, 'ND': 69001, 'OH': 40861,
    'OK': 68595, 'OR': 95988, 'PA': 44743, 'RI': 1034, 'SC': 30061, 'SD': 75811,
    'TN': 41235, 'TX': 261232, 'UT': 82170, 'VT': 9217, 'VA': 39490, 'WA': 66456,
    'WV': 24038, 'WI': 54158, 'WY': 97093
}

region_map = {}
for s in 'CT ME MA NH RI VT NJ NY PA'.split(): region_map[s] = 'Northeast'
for s in 'IL IN MI OH WI IA KS MN MO NE ND SD'.split(): region_map[s] = 'Midwest'
for s in 'DE DC FL GA MD NC SC VA WV AL KY MS TN AR LA OK TX'.split(): region_map[s] = 'South'
for s in 'AZ CO ID MT NV NM UT WY AK CA HI OR WA'.split(): region_map[s] = 'West'

# -----------------------------
# Derived state-year predictors
# -----------------------------
sy = state_year.copy()
sy['region'] = sy['state_abbr'].map(region_map)
sy['is_nm'] = (sy['state_abbr'] == 'NM').astype(int)
sy['year_centered'] = sy['year'] - sy['year'].mean()
sy['land_area_sqmi'] = sy['state_abbr'].map(land_area_sqmi)
sy['population_density'] = sy['population'] / sy['land_area_sqmi']
sy['log_density'] = np.log(sy['population_density'])
sy['log_population'] = np.log(sy['population'])

# Incident composition shares, same-year. These are descriptive/endogenous, not causal pre-treatment predictors.
for count_col, share_col in [
    ('armed_with_gun_count', 'gun_share'),
    ('unarmed_count', 'unarmed_share'),
    ('mental_illness_related_count', 'mental_illness_share'),
    ('body_camera_count', 'bodycam_share'),
    ('race_missing_count', 'race_missing_share')
]:
    sy[share_col] = np.where(sy['fatal_shootings'] > 0, sy[count_col] / sy['fatal_shootings'], 0.0)

# Agency/state-year features from bridge.
bridge2 = bridge.copy()
# Deduplicate by incident_id + agency_id so multi-agency incidents count correctly.
bridge2 = bridge2.drop_duplicates(['incident_id','agency_id'])
agency_sy = bridge2.groupby(['state_abbr','year']).agg(
    unique_agencies_with_shootings=('agency_id','nunique'),
    agency_event_rows=('agency_id','size'),
    multi_agency_rows=('multi_agency_incident','sum')
).reset_index()
# agency type shares by state-year
atype = (bridge2.pivot_table(index=['state_abbr','year'], columns='agency_type', values='incident_id', aggfunc='count', fill_value=0)
         .reset_index())
for c in ['local_police','sheriff','state_agency','other','federal']:
    if c not in atype.columns:
        atype[c]=0
atype['agency_type_total'] = atype[['local_police','sheriff','state_agency','other','federal']].sum(axis=1).replace(0,np.nan)
for c in ['local_police','sheriff','state_agency','other','federal']:
    atype[c + '_agency_share'] = atype[c] / atype['agency_type_total']

sy = sy.merge(agency_sy, on=['state_abbr','year'], how='left')
sy = sy.merge(atype[['state_abbr','year','local_police_agency_share','sheriff_agency_share','state_agency_agency_share','other_agency_share','federal_agency_share']], on=['state_abbr','year'], how='left')
for c in ['unique_agencies_with_shootings','agency_event_rows','multi_agency_rows','local_police_agency_share','sheriff_agency_share','state_agency_agency_share','other_agency_share','federal_agency_share']:
    sy[c] = sy[c].fillna(0)
sy['unique_agencies_per_1m'] = sy['unique_agencies_with_shootings'] / sy['population'] * 1_000_000
sy['multi_agency_share'] = np.where(sy['agency_event_rows']>0, sy['multi_agency_rows']/sy['agency_event_rows'],0)

# State-level concentration metrics.
city_counts = inc.groupby(['state_abbr','city']).size().reset_index(name='fatal_shootings_city')
city_tot = city_counts.groupby('state_abbr')['fatal_shootings_city'].sum().reset_index(name='state_fatal_shootings')
city_counts = city_counts.merge(city_tot, on='state_abbr')
city_counts['city_share'] = city_counts['fatal_shootings_city'] / city_counts['state_fatal_shootings']
city_hhi = city_counts.groupby('state_abbr').apply(lambda d: pd.Series({
    'top_city': d.sort_values('fatal_shootings_city', ascending=False).iloc[0]['city'],
    'top_city_count': int(d['fatal_shootings_city'].max()),
    'top_city_share': float(d['city_share'].max()),
    'city_hhi': float((d['city_share']**2).sum()),
    'num_cities_with_incidents': int(d['city'].nunique())
}), include_groups=False).reset_index()
county_counts = inc.groupby(['state_abbr','county']).size().reset_index(name='fatal_shootings_county')
county_tot = county_counts.groupby('state_abbr')['fatal_shootings_county'].sum().reset_index(name='state_fatal_shootings')
county_counts = county_counts.merge(county_tot, on='state_abbr')
county_counts['county_share'] = county_counts['fatal_shootings_county'] / county_counts['state_fatal_shootings']
county_hhi = county_counts.groupby('state_abbr').apply(lambda d: pd.Series({
    'top_county': d.sort_values('fatal_shootings_county', ascending=False).iloc[0]['county'],
    'top_county_count': int(d['fatal_shootings_county'].max()),
    'top_county_share': float(d['county_share'].max()),
    'county_hhi': float((d['county_share']**2).sum()),
    'num_counties_with_incidents': int(d['county'].nunique())
}), include_groups=False).reset_index()
state_conc = city_hhi.merge(county_hhi, on='state_abbr', how='outer')
sy = sy.merge(state_conc, on='state_abbr', how='left')

# Z-score selected continuous predictors.
def zscore(s):
    return (s - s.mean()) / s.std(ddof=0)
for col in ['log_density','gun_share','unarmed_share','mental_illness_share','bodycam_share','race_missing_share',
            'unique_agencies_per_1m','sheriff_agency_share','local_police_agency_share','multi_agency_share',
            'top_city_share','top_county_share','city_hhi','county_hhi']:
    sy[col + '_z'] = zscore(sy[col].fillna(0))

# Save modeling dataset.
sy.to_csv(OUT_DIR/'state_year_enriched_modeling_dataset.csv', index=False)
state_conc.to_csv(OUT_DIR/'state_concentration_features.csv', index=False)

# -----------------------------
# Negative binomial models
# -----------------------------
model_specs = [
    ('M0_region_year_nm', 'fatal_shootings ~ C(region) + is_nm + year_centered'),
    ('M1_add_density', 'fatal_shootings ~ C(region) + is_nm + year_centered + log_density_z'),
    ('M2_density_agency', 'fatal_shootings ~ C(region) + is_nm + year_centered + log_density_z + unique_agencies_per_1m_z + sheriff_agency_share_z + local_police_agency_share_z'),
    ('M3_density_incident_profile', 'fatal_shootings ~ C(region) + is_nm + year_centered + log_density_z + gun_share_z + mental_illness_share_z + bodycam_share_z'),
    ('M4_density_agency_profile', 'fatal_shootings ~ C(region) + is_nm + year_centered + log_density_z + unique_agencies_per_1m_z + sheriff_agency_share_z + gun_share_z + mental_illness_share_z + bodycam_share_z'),
    ('M5_state_concentration', 'fatal_shootings ~ C(region) + is_nm + year_centered + log_density_z + top_city_share_z + top_county_share_z')
]
model_rows = []
coef_tables = []
fits = {}
for name, formula in model_specs:
    try:
        mod = smf.negativebinomial(formula, data=sy, exposure=sy['population'])
        res = mod.fit(disp=0, maxiter=1000)
        fits[name] = res
        params = res.params
        conf = res.conf_int()
        pvals = res.pvalues
        nm_coef = params.get('is_nm', np.nan)
        nm_ci_low, nm_ci_high = conf.loc['is_nm'].tolist() if 'is_nm' in conf.index else (np.nan,np.nan)
        row = {
            'model_id': name,
            'formula': formula,
            'n_obs': int(res.nobs),
            'log_likelihood': float(res.llf),
            'aic': float(res.aic),
            'pseudo_r2_mcfadden': float(1 - res.llf / res.llnull) if hasattr(res, 'llnull') and res.llnull else np.nan,
            'converged': bool(res.mle_retvals.get('converged', True)),
            'nm_coef_log_rate': float(nm_coef),
            'nm_irr': float(np.exp(nm_coef)),
            'nm_irr_ci_low': float(np.exp(nm_ci_low)),
            'nm_irr_ci_high': float(np.exp(nm_ci_high)),
            'nm_p_value': float(pvals.get('is_nm', np.nan)),
            'alpha': float(params.get('alpha', np.nan)),
            'density_irr_per_1sd': float(np.exp(params.get('log_density_z', np.nan))) if 'log_density_z' in params.index else np.nan,
            'gun_share_irr_per_1sd': float(np.exp(params.get('gun_share_z', np.nan))) if 'gun_share_z' in params.index else np.nan,
            'unique_agencies_irr_per_1sd': float(np.exp(params.get('unique_agencies_per_1m_z', np.nan))) if 'unique_agencies_per_1m_z' in params.index else np.nan,
        }
        model_rows.append(row)
        ct = pd.DataFrame({
            'model_id': name,
            'term': params.index,
            'coef': params.values,
            'std_err': res.bse.values,
            'z': res.tvalues.values,
            'p_value': pvals.values,
            'ci_low': conf[0].values,
            'ci_high': conf[1].values,
            'irr': np.exp(params.values),
            'irr_ci_low': np.exp(conf[0].values),
            'irr_ci_high': np.exp(conf[1].values),
        })
        coef_tables.append(ct)
    except Exception as e:
        model_rows.append({'model_id':name, 'formula':formula, 'error':str(e)})

model_comparison = pd.DataFrame(model_rows)
model_comparison.to_csv(OUT_DIR/'negative_binomial_model_comparison.csv', index=False)
if coef_tables:
    pd.concat(coef_tables, ignore_index=True).to_csv(OUT_DIR/'negative_binomial_coefficients_all_models.csv', index=False)

# Residuals from best/sensible model M4 if fit; predicted mean uses .predict with exposure.
best_id = 'M4_density_agency_profile' if 'M4_density_agency_profile' in fits else list(fits.keys())[-1]
res = fits[best_id]
sy['predicted_fatal_shootings_enriched'] = res.predict(sy, exposure=sy['population'])
sy['residual_observed_minus_predicted_enriched'] = sy['fatal_shootings'] - sy['predicted_fatal_shootings_enriched']
sy['pearson_resid_enriched'] = sy['residual_observed_minus_predicted_enriched'] / np.sqrt(sy['predicted_fatal_shootings_enriched'] + fits[best_id].params.get('alpha',0) * sy['predicted_fatal_shootings_enriched']**2)
resid_state = sy.groupby(['state_abbr','state_name','region','is_nm']).agg(
    observed=('fatal_shootings','sum'),
    predicted_enriched=('predicted_fatal_shootings_enriched','sum'),
    residual_observed_minus_predicted=('residual_observed_minus_predicted_enriched','sum'),
    mean_pearson_resid=('pearson_resid_enriched','mean'),
    annualized_rate_per_1m=('fatal_shootings_per_1m','mean'),
    avg_density=('population_density','mean'),
    gun_share=('armed_with_gun_count','sum'),
    total=('fatal_shootings','sum')
).reset_index()
resid_state['gun_share'] = resid_state['gun_share'] / resid_state['total']
resid_state = resid_state.sort_values('residual_observed_minus_predicted', ascending=False)
resid_state.to_csv(OUT_DIR/'state_residuals_after_enriched_nb_model.csv', index=False)

# -----------------------------
# State-level correlations: explanatory screening
# -----------------------------
state_summary = sy.groupby(['state_abbr','state_name','region','is_nm']).agg(
    fatal_shootings=('fatal_shootings','sum'),
    avg_population=('population','mean'),
    annualized_rate_per_1m=('fatal_shootings_per_1m','mean'),
    avg_density=('population_density','mean'),
    avg_log_density=('log_density','mean'),
    unarmed_count=('unarmed_count','sum'),
    gun_count=('armed_with_gun_count','sum'),
    mental_count=('mental_illness_related_count','sum'),
    bodycam_count=('body_camera_count','sum'),
    race_missing_count=('race_missing_count','sum'),
    unique_agencies_with_shootings_total=('unique_agencies_with_shootings','sum'),
    unique_agencies_per_1m_mean=('unique_agencies_per_1m','mean'),
    sheriff_share_mean=('sheriff_agency_share','mean'),
    local_police_share_mean=('local_police_agency_share','mean'),
    top_city_share=('top_city_share','first'),
    top_city=('top_city','first'),
    top_county_share=('top_county_share','first'),
    top_county=('top_county','first'),
    city_hhi=('city_hhi','first'),
    county_hhi=('county_hhi','first')
).reset_index()
state_summary['gun_share'] = state_summary['gun_count'] / state_summary['fatal_shootings']
state_summary['unarmed_share'] = state_summary['unarmed_count'] / state_summary['fatal_shootings']
state_summary['mental_illness_share'] = state_summary['mental_count'] / state_summary['fatal_shootings']
state_summary['bodycam_share'] = state_summary['bodycam_count'] / state_summary['fatal_shootings']
state_summary['race_missing_share'] = state_summary['race_missing_count'] / state_summary['fatal_shootings']
state_summary.to_csv(OUT_DIR/'state_level_factor_screening_dataset.csv', index=False)

factor_cols = ['avg_log_density','avg_density','gun_share','unarmed_share','mental_illness_share','bodycam_share','race_missing_share','unique_agencies_per_1m_mean','sheriff_share_mean','local_police_share_mean','top_city_share','top_county_share','city_hhi','county_hhi']
corr_rows=[]
for col in factor_cols:
    x = state_summary[col].replace([np.inf,-np.inf],np.nan)
    y = state_summary['annualized_rate_per_1m']
    mask = x.notna() & y.notna()
    if mask.sum() >= 4:
        pr = stats.pearsonr(x[mask], y[mask])
        sr = stats.spearmanr(x[mask], y[mask])
        corr_rows.append({
            'factor': col,
            'pearson_r': pr.statistic,
            'pearson_p': pr.pvalue,
            'spearman_rho': sr.statistic,
            'spearman_p': sr.pvalue,
        })
corr = pd.DataFrame(corr_rows).sort_values('spearman_p')
corr.to_csv(OUT_DIR/'state_factor_correlations_with_rate.csv', index=False)

# NM factor profile vs rest of country and West excluding NM.
nm_profile = []
metrics = ['annualized_rate_per_1m','avg_density','gun_share','unarmed_share','mental_illness_share','bodycam_share','race_missing_share','unique_agencies_per_1m_mean','sheriff_share_mean','local_police_share_mean','top_city_share','top_county_share']
for metric in metrics:
    nm_val = state_summary.loc[state_summary.state_abbr=='NM', metric].iloc[0]
    rest = state_summary.loc[state_summary.state_abbr!='NM', metric]
    west_rest = state_summary.loc[(state_summary.region=='West') & (state_summary.state_abbr!='NM'), metric]
    nm_profile.append({
        'metric': metric,
        'new_mexico': nm_val,
        'rest_us_mean': rest.mean(),
        'rest_us_median': rest.median(),
        'west_excluding_nm_mean': west_rest.mean(),
        'west_excluding_nm_median': west_rest.median(),
        'nm_vs_rest_mean_ratio': nm_val / rest.mean() if rest.mean() else np.nan,
        'nm_vs_west_ex_nm_mean_ratio': nm_val / west_rest.mean() if west_rest.mean() else np.nan,
        'nm_percentile_among_states': stats.percentileofscore(state_summary[metric].dropna(), nm_val, kind='rank')
    })
profile = pd.DataFrame(nm_profile)
profile.to_csv(OUT_DIR/'new_mexico_factor_profile_vs_comparators.csv', index=False)

# -----------------------------
# Plots
# -----------------------------
created=[]
def savefig(fn):
    path = OUT_DIR/'figures'/fn
    plt.tight_layout()
    plt.savefig(path, dpi=220, bbox_inches='tight')
    plt.close()
    created.append(str(path))

# NM IRR across models
mc = model_comparison.dropna(subset=['nm_irr']).copy()
mc = mc.sort_values('model_id')
plt.figure(figsize=(10,6))
ypos = np.arange(len(mc))
plt.errorbar(mc['nm_irr'], ypos, xerr=[mc['nm_irr']-mc['nm_irr_ci_low'], mc['nm_irr_ci_high']-mc['nm_irr']], fmt='o', capsize=4)
plt.axvline(1, linestyle='--', linewidth=1)
plt.yticks(ypos, mc['model_id'])
plt.xlabel('New Mexico incidence rate ratio')
plt.ylabel('Model')
plt.title('New Mexico Effect Across Negative Binomial Models')
plt.grid(True, axis='x', alpha=0.3)
savefig('01_nm_incidence_rate_ratio_across_models.png')

# Rate vs density
plt.figure(figsize=(9,7))
for region in ['West','South','Midwest','Northeast']:
    d=state_summary[state_summary.region==region]
    plt.scatter(d['avg_density'], d['annualized_rate_per_1m'], label=region, alpha=0.75)
plt.xscale('log')
for _, r in state_summary[state_summary.state_abbr.isin(['NM','AK','AZ','CO','OK','NY','MA','NJ','CA','TX'])].iterrows():
    plt.annotate(r.state_abbr, (r.avg_density, r.annualized_rate_per_1m), fontsize=8)
plt.xlabel('Average population density, 2015–2024 (log scale)')
plt.ylabel('Annualized fatal shooting rate per 1M')
plt.title('State Fatal Police Shooting Rate vs Population Density')
plt.legend()
plt.grid(True, alpha=0.3)
savefig('02_rate_vs_population_density.png')

# Rate vs gun share
plt.figure(figsize=(9,7))
for region in ['West','South','Midwest','Northeast']:
    d=state_summary[state_summary.region==region]
    plt.scatter(d['gun_share']*100, d['annualized_rate_per_1m'], label=region, alpha=0.75)
for _, r in state_summary[state_summary.state_abbr.isin(['NM','AK','AZ','CO','OK','NY','MA','NJ','CA','TX'])].iterrows():
    plt.annotate(r.state_abbr, (r.gun_share*100, r.annualized_rate_per_1m), fontsize=8)
plt.xlabel('Share of fatal incidents recorded as armed with gun (%)')
plt.ylabel('Annualized fatal shooting rate per 1M')
plt.title('State Rate vs Gun-Involved Share of Fatal Incidents')
plt.legend()
plt.grid(True, alpha=0.3)
savefig('03_rate_vs_gun_involved_share.png')

# Residual extremes after enriched model
ext = pd.concat([resid_state.nsmallest(10,'residual_observed_minus_predicted'), resid_state.nlargest(10,'residual_observed_minus_predicted')]).drop_duplicates().sort_values('residual_observed_minus_predicted')
plt.figure(figsize=(10,8))
plt.barh(ext['state_abbr'], ext['residual_observed_minus_predicted'])
plt.axvline(0, linewidth=1)
plt.xlabel('Observed minus predicted fatal shootings, 2015–2024')
plt.ylabel('State')
plt.title(f'Largest State Residuals After Enriched NB Model ({best_id})')
plt.grid(True, axis='x', alpha=0.3)
savefig('04_enriched_model_state_residuals.png')

# Factor correlation plot
corr_plot = corr.sort_values('spearman_rho')
plt.figure(figsize=(9,7))
plt.barh(corr_plot['factor'], corr_plot['spearman_rho'])
plt.axvline(0, linewidth=1)
plt.xlabel('Spearman correlation with annualized fatal shooting rate')
plt.ylabel('Factor')
plt.title('State-Level Factor Screening Correlations')
plt.grid(True, axis='x', alpha=0.3)
savefig('05_factor_correlations_with_rate.png')

# NM profile ratios
prof_plot = profile[profile['metric'].isin(['annualized_rate_per_1m','avg_density','gun_share','unique_agencies_per_1m_mean','sheriff_share_mean','top_city_share','top_county_share'])].copy()
plt.figure(figsize=(10,6))
ypos=np.arange(len(prof_plot))
plt.barh(ypos, prof_plot['nm_vs_west_ex_nm_mean_ratio'])
plt.axvline(1, linewidth=1)
plt.yticks(ypos, prof_plot['metric'])
plt.xlabel('New Mexico / West excluding NM mean')
plt.ylabel('Metric')
plt.title('New Mexico Factor Profile Relative to Other Western States')
plt.grid(True, axis='x', alpha=0.3)
savefig('06_nm_factor_profile_vs_west_excluding_nm.png')

# Observed vs predicted enriched
plt.figure(figsize=(8,8))
plt.scatter(resid_state['predicted_enriched'], resid_state['observed'], alpha=0.75)
mn = min(resid_state['predicted_enriched'].min(), resid_state['observed'].min())
mx = max(resid_state['predicted_enriched'].max(), resid_state['observed'].max())
plt.plot([mn,mx],[mn,mx])
for _, r in resid_state[resid_state.state_abbr.isin(['NM','AK','AZ','CO','OK','NY','MA','NJ','CA','TX'])].iterrows():
    plt.annotate(r.state_abbr, (r.predicted_enriched, r.observed), fontsize=8)
plt.xlabel('Predicted fatal shootings, 2015–2024')
plt.ylabel('Observed fatal shootings, 2015–2024')
plt.title(f'Observed vs Predicted by State: Enriched NB Model ({best_id})')
plt.grid(True, alpha=0.3)
savefig('07_observed_vs_predicted_enriched_model.png')

# -----------------------------
# Write report and source notes
# -----------------------------
# Extract headline results.
def fmt(x, nd=3):
    if pd.isna(x): return 'NA'
    return f'{x:.{nd}f}'

m0 = model_comparison[model_comparison.model_id=='M0_region_year_nm'].iloc[0]
mbest = model_comparison[model_comparison.model_id==best_id].iloc[0]
nm_row = state_summary[state_summary.state_abbr=='NM'].iloc[0]
resid_nm = resid_state[resid_state.state_abbr=='NM'].iloc[0]

report = f"""# Next-Step Factor Model: New Mexico and State-Level Drivers

## Purpose

This package extends the prior region/year/New Mexico model by adding internal diagnostic factors that can help screen possible explanations for state-level variation in fatal police shooting rates. The focus is New Mexico because the earlier model showed that New Mexico remained elevated even after adjusting for population, region, and year trend.

## Important caution

Several variables in this package are **descriptive incident-composition variables** calculated from the same fatal-shooting dataset, such as gun-involved share, mental-illness-related share, and body-camera share. Those variables are useful for profiling the structure of fatal incidents, but they should **not** be interpreted as clean causal predictors. They occur inside the outcome process, so they can explain composition, not root-cause exposure.

## Data created

- `state_year_enriched_modeling_dataset.csv`: state-year modeling table with population offset, region, density, incident composition, agency-involvement proxies, and city/county concentration metrics.
- `negative_binomial_model_comparison.csv`: model-by-model comparison, including New Mexico incidence-rate ratio.
- `negative_binomial_coefficients_all_models.csv`: full coefficients and exponentiated incidence-rate ratios for every model.
- `state_residuals_after_enriched_nb_model.csv`: observed-minus-predicted state residuals from the enriched model.
- `state_factor_correlations_with_rate.csv`: simple state-level correlation screen.
- `new_mexico_factor_profile_vs_comparators.csv`: New Mexico profile versus rest of U.S. and West excluding New Mexico.

## Model sequence

The model sequence begins with the earlier region/year/New Mexico specification and then adds density, agency-involvement proxies, incident profile variables, and geographic concentration metrics.

Baseline model New Mexico IRR: **{fmt(m0['nm_irr'],2)}**  
Baseline 95% CI: **{fmt(m0['nm_irr_ci_low'],2)}–{fmt(m0['nm_irr_ci_high'],2)}**  
Baseline p-value: **{fmt(m0['nm_p_value'],4)}**

Selected enriched model: **{best_id}**  
Enriched model New Mexico IRR: **{fmt(mbest['nm_irr'],2)}**  
Enriched 95% CI: **{fmt(mbest['nm_irr_ci_low'],2)}–{fmt(mbest['nm_irr_ci_high'],2)}**  
Enriched p-value: **{fmt(mbest['nm_p_value'],4)}**

## New Mexico profile

New Mexico's annualized fatal police shooting rate in this dataset is **{fmt(nm_row['annualized_rate_per_1m'],2)} per 1M residents**. Its average population density is **{fmt(nm_row['avg_density'],1)} persons per square mile**, and **{fmt(nm_row['gun_share']*100,1)}%** of its fatal incidents were recorded as gun-involved. Albuquerque remains important: the top city share for New Mexico is **{fmt(nm_row['top_city_share']*100,1)}%**.

After the enriched model, New Mexico's observed total was **{int(resid_nm['observed'])}**, predicted total was **{fmt(resid_nm['predicted_enriched'],1)}**, and residual was **{fmt(resid_nm['residual_observed_minus_predicted'],1)}**.

## Main finding

The New Mexico coefficient remains elevated across model specifications. Adding density, agency-involvement proxies, and incident-profile variables changes the size of the New Mexico coefficient, but it does not erase the outlier signal. In practical terms, New Mexico does not look high merely because it is Western, low-density, or because the national trend changed over time.

## Interpretation

The strongest defensible conclusion is that New Mexico's high rate likely reflects a factor stack rather than a single cause: a Western/low-density policing environment, a high share of gun-involved fatal incidents, significant Albuquerque/Bernalillo concentration, and possibly agency-level or local institutional conditions not captured in this dataset. The next true external-data step should merge FBI violent crime, ACS socioeconomic variables, CDC firearm mortality, and BJS/LEMAS police staffing/policy variables.

## Recommended next model

The next publishable model should be a state-year negative-binomial or hierarchical count model using population offset and external covariates:

`fatal_shootings ~ region + year + violent_crime_rate + firearm_mortality_rate + poverty_rate + unemployment_rate + population_density + officers_per_capita + agency_count_per_capita + mental_health_provider_shortage + is_nm`

Then check whether `is_nm` remains large. If it does, the analysis should move down to county or agency level, especially Albuquerque/Bernalillo County.
"""
(OUT_DIR/'next_step_factor_model_report.md').write_text(report)

source_notes = """# Source and Method Notes

Core fatal-shooting data: Washington Post Fatal Force dataset from the cleaned project package. Population data: Census Population Estimates Program data already merged in the cleaned project package.

Land-area values are stable state land-area approximations used to compute population density. For a fully audited external-data release, replace this static dictionary with a fresh Census Gazetteer state-land-area table.

Recommended external sources for next merge:
- Census ACS 5-year profiles/detailed tables for poverty, income, education, demographic structure, and housing context: https://www.census.gov/data/developers/data-sets/acs-5year.html
- Census Population Estimates Program for annual state population denominators: https://www.census.gov/programs-surveys/popest.html
- FBI Crime Data Explorer/UCR estimates for violent crime and homicide rates: https://cde.ucr.cjis.gov/LATEST/webapp/
- CDC WONDER/NCHS for firearm mortality and other mortality/public-health indicators: https://wonder.cdc.gov/
- BJS LEMAS for law-enforcement agency staffing, expenditures, training, equipment, and policy variables: https://bjs.ojp.gov/data-collection/law-enforcement-management-and-administrative-statistics-lemas
"""
(OUT_DIR/'source_and_method_notes.md').write_text(source_notes)

# Write reproducibility script copy.
shutil.copyfile('/mnt/data/build_next_step_factor_model.py', OUT_DIR/'build_next_step_factor_model.py')

# Zip package.
zip_path = '/mnt/data/police_shootings_next_step_factor_model.zip'
if os.path.exists(zip_path):
    os.remove(zip_path)
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in OUT_DIR.rglob('*'):
        z.write(p, arcname=str(p.relative_to(OUT_DIR.parent)))

print(json.dumps({
    'zip_path': zip_path,
    'out_dir': str(OUT_DIR),
    'best_model': best_id,
    'model_comparison': model_comparison[['model_id','nm_irr','nm_irr_ci_low','nm_irr_ci_high','nm_p_value','aic','alpha']].to_dict(orient='records'),
    'nm_enriched_residual': resid_nm[['observed','predicted_enriched','residual_observed_minus_predicted']].to_dict(),
    'created_figures': [os.path.basename(p) for p in created]
}, indent=2))
